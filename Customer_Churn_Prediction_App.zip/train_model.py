import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
import joblib

df = pd.read_csv("Telco-Customer-Churn.csv")
df = df[["gender", "SeniorCitizen", "MonthlyCharges", "tenure", "Contract", "Churn"]]
df = df.dropna()

X = df.drop("Churn", axis=1)
y = df["Churn"]

encoder = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
X_encoded = encoder.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(X_encoded, y, test_size=0.2, stratify=y)

model = RandomForestClassifier()
model.fit(X_train, y_train)

joblib.dump(model, "app/model.pkl")
joblib.dump(encoder, "app/encoder.pkl")
print("✅ Model and encoder saved in 'app/' folder.")
