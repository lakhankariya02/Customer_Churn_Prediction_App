import streamlit as st
import pandas as pd
import joblib

st.set_page_config(page_title="Customer Churn Predictor")

st.title("📉 Customer Churn Predictor")

model = joblib.load("model.pkl")
encoder = joblib.load("encoder.pkl")

st.sidebar.header("Enter Customer Details")

gender = st.sidebar.selectbox("Gender", ["Male", "Female"])
senior = st.sidebar.selectbox("Senior Citizen", [0, 1])
monthly_charges = st.sidebar.slider("Monthly Charges", 0, 200, 70)
tenure = st.sidebar.slider("Tenure (Months)", 0, 72, 12)
contract = st.sidebar.selectbox("Contract Type", ["Month-to-month", "One year", "Two year"])

if st.sidebar.button("Predict Churn"):
    input_df = pd.DataFrame({
        "gender": [gender],
        "SeniorCitizen": [senior],
        "MonthlyCharges": [monthly_charges],
        "tenure": [tenure],
        "Contract": [contract]
    })
    input_encoded = encoder.transform(input_df)
    prediction = model.predict(input_encoded)
    st.subheader("Prediction Result:")
    st.success("✅ Likely to Stay" if prediction[0] == "No" else "⚠️ Likely to Churn")
