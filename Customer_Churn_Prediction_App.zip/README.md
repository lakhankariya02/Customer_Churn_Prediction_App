# Customer Churn Predictor

### How to Run

1. Install requirements:
```bash
pip install -r requirements.txt
```

2. Download dataset from:
https://www.kaggle.com/datasets/blastchar/telco-customer-churn

Save it as: `Telco-Customer-Churn.csv`

3. Train model:
```bash
python train_model.py
```

4. Run the app:
```bash
cd app
streamlit run app.py
```
